using System;

class Cliente {
        public string Nome {get; set;}
        public string Cpf {get; private set;}
        public int Idade {get; private set;}
}