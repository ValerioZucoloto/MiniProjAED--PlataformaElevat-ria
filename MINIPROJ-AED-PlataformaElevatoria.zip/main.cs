using System;

class MainClass {
  public static void Main (string[] args) {
    //http://codepad.org/VwIDTKG8
    //tiny.cc/miniprojaed

    Plataforma JLG = new Plataforma();

    
  }
}